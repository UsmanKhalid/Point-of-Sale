﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PointofSale
{
    /// <summary>
    /// Interaction logic for Main_Menu.xaml
    /// </summary>
    public partial class Main_Menu : Window
    {
        public Main_Menu()
        {
            InitializeComponent();
        }

        private void btn_Cash_Register_Click(object sender, RoutedEventArgs e)
        {
            Cash_Register cash_reg = new Cash_Register();
            cash_reg.Show();
        }

        private void btn_PurchaseOrder_Click(object sender, RoutedEventArgs e)
        {
            Purchase_Order p_order = new Purchase_Order();
            p_order.Show();
        }
        private void btn_ManageUser_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Hello btn_ManageUser_Click ");
        }
        private void btn_DailyReport_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Hello btn_DailyReport_Click");
        }


    }
}
