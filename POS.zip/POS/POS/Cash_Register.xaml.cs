﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PointofSale
{
    /// <summary>
    /// Interaction logic for Cash_Register.xaml
    /// </summary>
    public partial class Cash_Register : Window
    {
        public Cash_Register()
        {
            InitializeComponent();
            BindComboBox();
            
        }
        ObservableCollection<SaleItem> saleitems = new ObservableCollection<SaleItem>();
        public void BindComboBox()
        {
            MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ToString());
            MySqlDataAdapter da = new MySqlDataAdapter("Select Distinct(Product_Name) FROM product", conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "product");
            drpdwn_ProductName.ItemsSource = ds.Tables[0].DefaultView;
            drpdwn_ProductName.DisplayMemberPath = ds.Tables[0].Columns["Product_Name"].ToString();
            drpdwn_ProductName.SelectedValuePath = ds.Tables[0].Columns["Product_Name"].ToString();
        }

        private void NumberValidationTextbox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);

        }

        private void drpdwn_ProductName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string ProductName = drpdwn_ProductName.SelectedValue.ToString();
            string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ToString();
            MySqlConnection conn = new MySqlConnection(conStr);
            try
            {
                conn.Open();
                MySqlCommand comm = conn.CreateCommand();
                comm.CommandText = " select  Unit_Price from product where Product_Name = @Product_Name";
                comm.Parameters.AddWithValue("@Product_Name", ProductName);
                decimal Unit_Price = (decimal)comm.ExecuteScalar();
              
                conn.Close();
                txt_UnitPrice.Text = Unit_Price.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void Add_Item_Click(object sender, RoutedEventArgs e)
        {
           
           SaleItem saleitem =  new SaleItem { Product_Name=drpdwn_ProductName.SelectedValue.ToString(),Unit_Price = Convert.ToDecimal(  txt_UnitPrice.Text),Quantity = Convert.ToInt16( txt_Quantity.Text),Total_Price= Convert.ToInt16( txt_Quantity.Text) * Convert.ToDecimal (txt_UnitPrice.Text) };

            saleitems.Add(saleitem);
          
            datagrid_Items.ItemsSource = saleitems;
            txt_TotalPrice.Text = saleitems.Sum(x => x.Total_Price).ToString();
        }

        public class SaleItem {

            public int Product_Id { get; set; }
            public string Product_Name { get; set; }

            public int Quantity { get; set; }


            public decimal Unit_Price { get; set; }


            public decimal Total_Price
            {

                get;



                set;

            }

        
        }

        private void checkout_Click(object sender, RoutedEventArgs e)
        {

            string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ToString();
            MySqlConnection conn = new MySqlConnection(conStr);
            try
            {
                conn.Open();
                MySqlCommand comm = conn.CreateCommand();
                comm.CommandText = "INSERT INTO invoice(invoice_date,invoice_total) VALUES(@invoicedate, @totalinvoice)";
                comm.Parameters.AddWithValue("@invoicedate", DateTime.Now);
                comm.Parameters.AddWithValue("@totalinvoice", Convert.ToDecimal(txt_TotalPrice.Text));
                comm.ExecuteNonQuery();
                int Invoiceid = (int)comm.LastInsertedId;
               

                MySqlCommand detailcomm = conn.CreateCommand();
                detailcomm.CommandText = "INSERT INTO invoicedetail(product_name,unit_price,quantity,itemtotal,invoice_date,invoice_id) VALUES(@product_name, @unit_price,@quantity,@itemtotal,@invoice_date,@invoiceid)";

                foreach (var item in saleitems)
                {
                    detailcomm.Parameters.Clear();
                    detailcomm.Parameters.AddWithValue("@product_name", item.Product_Name);
                    detailcomm.Parameters.AddWithValue("@unit_price", item.Unit_Price);
                    detailcomm.Parameters.AddWithValue("@quantity", item.Quantity);
                    detailcomm.Parameters.AddWithValue("@itemtotal", item.Quantity * item.Unit_Price);
                    detailcomm.Parameters.AddWithValue("@invoice_date", DateTime.Now);
                    detailcomm.Parameters.AddWithValue("@invoiceid", Invoiceid);
                    detailcomm.ExecuteNonQuery();
                }
                conn.Close();
                saleitems.Clear();
                txt_TotalPrice.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        private void datagrid_Items_AutoGeneratedColumns(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            
        }

       
    }
}
