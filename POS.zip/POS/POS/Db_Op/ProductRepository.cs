﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace PointofSale.Db_Op
{
   public  class ProductRepository
    {
       static string conStr = ConfigurationSettings.AppSettings["connectionString"].ToString();
       public  static void AddProduct() { }


       public static void GetProduct() {

           MySqlConnection conn = new MySqlConnection(conStr);
           try
           {
              
               conn.Open();

               string sql = "SELECT  ProductName from product  ";
               MySqlCommand cmd = new MySqlCommand(sql, conn);
               MySqlDataReader rdr = cmd.ExecuteReader();

               while (rdr.Read())
               {
                string ss =   (rdr[0] + " -- " + rdr[1]);
               }
               rdr.Close();
           }
           catch (Exception ex)
           {
               Console.WriteLine(ex.ToString());
           }



       
       
       }

    }
}
