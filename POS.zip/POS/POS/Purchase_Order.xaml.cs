﻿using MySql.Data.MySqlClient;
using PointofSale.Db_Op;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PointofSale
{
    /// <summary>
    /// Interaction logic for Purchase_Order.xaml
    /// </summary>
    public partial class Purchase_Order : Window
    {
        public Purchase_Order()
        {
            InitializeComponent();
        }

        private void NumberValidationTextbox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);

        }


        private void NumberDecimalValidationTextbox(object sender, TextCompositionEventArgs e)
        {
            var regex = new Regex(@"^[0-9]*(?:\.[0-9]*)?$");
            if (regex.IsMatch(e.Text) && !(e.Text == "." && ((TextBox)sender).Text.Contains(e.Text)))
                e.Handled = false;

            else
                e.Handled = true;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // items are added
            ProductRepository.GetProduct();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

            string ProductName = txt_ProductName.Text;
            int Type  = (int) (ProductType)Enum.Parse(typeof(ProductType), drpdwn_ProductType.SelectedValue.ToString());
            int Quantity = Convert.ToInt16( txt_Qty.Text);
            double Unit_Price  = Convert.ToDouble (txt_UnitPrice.Text);


            InsertProduct(ProductName, Type, Quantity, Unit_Price);
        }
        private void InsertProduct(string Product_Name, int Quanitity, int Type, double Unit_Price)
        {
            string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ToString();
            MySqlConnection conn = new MySqlConnection(conStr);
            try
            {
                conn.Open();
                MySqlCommand comm = conn.CreateCommand();
                comm.CommandText = "INSERT INTO product(Product_Name,Quantity,Type,Unit_Price) VALUES(@Product_Name, @Quantity,@Type,@Unit_Price)";
                comm.Parameters.AddWithValue("@Product_Name",Product_Name );
                comm.Parameters.AddWithValue("@Quantity", Quanitity);
                comm.Parameters.AddWithValue("@Type",Type );
                comm.Parameters.AddWithValue("@Unit_Price", Unit_Price);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            



        }
       
        enum ProductType {Bakery=1,Snacks,Drink};

    }
}
